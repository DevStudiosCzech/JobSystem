fx_version 'bodacious'
game 'gta5'

description 'JobSystem pro ESX'
author 'payomancz <payoman#0>'

version '1.0.0'

lua54 'yes'

server_scripts {
	'@mysql-async/lib/MySQL.lua',
	'@es_extended/locale.lua',
	'config.lua',
	'locales/*.lua',
	'server/*.lua'
}

client_scripts {
	'@es_extended/locale.lua',
	'config.lua',
	'locales/*.lua',
	'client/*.lua'
}

dependency 'es_extended'

dependency '/assetpacks'